The raw data can be downloaded from 'https://www.ncdc.noaa.gov/orders/qclcd/QCLCDYYYYMM.zip'

In linux machine, it is easily done by 'wget' command.
Example code:
$ cd ~/EnRoutePerformance/NOAA
$ mkdir raw
$ cd raw
$ wget https://www.ncdc.noaa.gov/orders/qclcd/QCLCD201301.zip

After download all required NOAA data, please run GetWx_ARTCC.py to convert the binary file into an ARTCC-based UTC summary file.
Example output for CY 2013 is recorded in '/NOAA/ARTCC_Based_Weather_Sum_UTC.csv'
